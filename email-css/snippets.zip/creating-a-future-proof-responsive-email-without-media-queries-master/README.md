### Tuts+ Tutorial: Creating a Future-Proof Responsive Email Without Media Queries
#### Instructor: Nicole Merlin

Using this ‘fluid hybrid’ method you can build an HTML email with lots of different layouts that doesn't rely on media queries to look great on mobile devices.

Source files for the Tuts+ tutorial: [Creating a Future-Proof Responsive Email Without Media Queries](http://webdesign.tutsplus.com/tutorials/creating-a-future-proof-responsive-email-without-media-queries--cms-23919)

**Available on Tuts+ June, 2015**

[View the demo](http://tutsplus.github.io/creating-a-future-proof-responsive-email-without-media-queries/index.html)
